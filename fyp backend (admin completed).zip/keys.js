module.exports = {
    
    mongoUrl: "mongodb+srv://Admin:FypAdmin01@cluster0.a8rxt.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    jwtKey: 'asbdkjabfkjand',
    sendGridKey: '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',

}